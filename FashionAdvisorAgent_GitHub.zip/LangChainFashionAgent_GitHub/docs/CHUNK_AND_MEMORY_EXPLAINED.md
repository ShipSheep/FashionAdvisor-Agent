# Chunk 与摘要记忆机制说明

## 1. Chunk 不是固定长度硬切

本项目中的 `CHUNK_SIZE=800` 表示“一个 chunk 的目标上限”，不是“每 800 个字符强制切一刀”。

具体流程：

1. 先识别 TXT 的结构标题，例如：
   - `一、春季服装`
   - `1. 纯棉材质`
2. 把一个编号知识点和它下面的正文先组成一个逻辑块。
3. 如果这个逻辑块不超过 800 字，整块保留。
4. 只有逻辑块本身超过 800 字，才使用 `RecursiveCharacterTextSplitter` 继续切分。
5. 递归切分优先级：
   - 空行 / 自然段
   - 换行
   - 中文句号、问号、感叹号、分号
   - 逗号
   - 最后才退化到字符
6. 超长块切分时保留 `CHUNK_OVERLAP=120`。
7. 每个 child chunk 都重复带上所属标题，避免正文脱离主题。

因此它属于：**结构感知切分 + 递归自然边界兜底**。

## 2. 为什么没有直接使用 SemanticChunker

Embedding-based semantic splitting 的确可以根据语义变化寻找边界，但会增加：

- Embedding 调用次数；
- 额外费用；
- 构建知识库的耗时；
- 实验性组件或额外 provider 依赖；
- 阈值调参难度。

当前三份原始 TXT 本身已经有非常清晰的“季节 / 编号 / 材质 / 条目”结构，优先使用文档已有结构通常比再让模型猜语义边界更稳定。

后续如果知识库变成大量无标题长文章，再考虑 Semantic Chunking 会更有价值。

## 3. 检索阶段为什么还要扩展邻居

入库切得再好，也可能遇到查询正好命中一个边界块。

所以 Retriever 采用：

```text
Query
  -> MMR anchor chunks
  -> anchor 前一个 chunk
  -> anchor 本身
  -> anchor 后一个 chunk
  -> 去重后交给 Agent
```

例如 anchor 是 chunk 3，`RETRIEVAL_NEIGHBOR_WINDOW=1`：

```text
chunk 2 + chunk 3 + chunk 4
```

这相当于给检索结果补一个小型上下文窗口。

## 4. 三份 TXT 的处理方式

### 洗涤养护.txt

进入 RAG。

### 颜色选择.txt

进入 RAG。

### 尺码推荐_原始数据.txt

**不作为主要 RAG 数据入库。**

它被结构化成：

```text
data/size_chart.json
```

然后由：

```text
recommend_size Tool
```

执行确定性计算。

原因：尺码是明确区间规则，不应该让 LLM 从相似文本里猜。

---

# 5. SQLite + SummarizationMiddleware

SQLite 和摘要各自解决不同问题：

```text
SQLite = 持久化
SummarizationMiddleware = 控制上下文长度
```

完整流程：

```text
用户不断聊天
   ↓
SqliteSaver 持久化 Agent state
   ↓
消息越来越多
   ↓
达到 token 或 message 阈值
   ↓
SummarizationMiddleware 调用摘要模型
   ↓
旧消息 -> 结构化摘要
最近 10 条 -> 保留原文
   ↓
新的压缩后 state 再写入 SQLite
```

默认触发条件：

```text
tokens >= 6000
OR
messages >= 30
```

摘要后：

```text
最近 10 条 messages 仍然保持原始内容
```

这些值都能在 `.env` 调整。

## 6. 摘要应该保留什么

本项目自定义 `MEMORY_SUMMARY_PROMPT`，要求优先保存：

- 用户事实；
- 用户偏好与约束；
- 已形成的结论；
- 未解决问题；
- 会影响未来回答的 Tool 结果。

普通问候、重复表达则可以被压缩掉。

这样摘要更像“Agent Memory”，而不是普通文章摘要。

---

# 7. 为什么还要有 Relevance Gate + Tavily

向量数据库即使面对完全无关的问题，也可能返回 Top-K，因此：

```text
documents != []
```

不能证明“知识库有答案”。

系统先通过 relevance score 做 Gate：

```text
Query
 -> relevance score
 -> best_score >= threshold ?
```

通过才继续 MMR + Neighbor Expansion；不通过则返回：

```text
LOCAL_KB_STATUS=INSUFFICIENT
```

如果问题属于公开互联网知识，Agent 可以继续调用独立的：

```text
web_search
```

该 Tool 使用 Tavily。

本项目不把 Tavily 写死在 Retriever 内部，因为本地知识检索和互联网搜索是两种不同能力，应该让 Agent 根据 Observation 决定下一步。

对于“最新 / 当前 / 今年 / 近期趋势”等明显实时问题，Agent 可以直接使用 Web Search，而不必先查静态本地库。
