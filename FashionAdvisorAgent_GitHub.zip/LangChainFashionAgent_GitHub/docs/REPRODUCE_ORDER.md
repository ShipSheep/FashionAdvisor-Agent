# 从零复现：推荐代码编写顺序

不要按文件夹字母顺序写，而要按“底层依赖 -> RAG -> Tool -> Memory -> Agent -> 应用”的依赖顺序。

完整复现文档请阅读：`FROM_ZERO_TO_ONE_TUTORIAL.md`。

## 推荐顺序

1. `requirements.txt`
2. `.env.example` -> `.env`
3. `config.py`
4. `models/model_factory.py`
5. `rag/text_splitter.py`
6. `rag/vector_store.py`
7. `rag/knowledge_base.py`
8. `scripts/preview_chunks.py`
9. `scripts/init_knowledge_base.py`
10. `rag/retriever.py`
11. `scripts/inspect_relevance.py`
12. `tools/knowledge_tool.py`
13. `tools/size_tool.py`
14. `tools/weight_tool.py`
15. `tools/web_search_tool.py`
16. `agent/prompts.py`
17. `memory/sqlite_memory.py`
18. `memory/summary_middleware.py`
19. `agent/agent_service.py`
20. `tests/test_text_splitter.py`
21. `tests/test_tools.py`
22. `tests/test_retrieval_gate.py`
23. `tests/test_web_search.py`
24. `tests/test_agent.py`
25. `main.py`

## 推荐执行顺序

```bash
pip install -r requirements.txt

python scripts/preview_chunks.py
python tests/test_tools.py
python scripts/init_knowledge_base.py
python scripts/inspect_relevance.py
python tests/test_retrieval_gate.py
python tests/test_web_search.py
python tests/test_agent.py
python main.py
```
