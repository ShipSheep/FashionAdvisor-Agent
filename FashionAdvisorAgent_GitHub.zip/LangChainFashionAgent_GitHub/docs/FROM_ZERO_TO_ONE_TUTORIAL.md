# FashionAdvisor Agent：从 0 到 1 完整复现

> 项目：FashionAdvisor Agent  
> 核心能力：Agentic RAG + Structure-aware Chunking + Relevance Gate + MMR + Neighbor Expansion + Tavily Web Search + SQLite Persistent Memory + Conversation Summarization

---

# 0. 学这个项目时最重要的目标

不要把目标理解成：

> “把这些 Python 文件复制到电脑上，能跑就行。”

真正应该掌握的是下面 6 个问题：

1. 为什么 RAG 不应该成为所有用户问题的固定入口？
2. 为什么不同类型的知识应该做成不同 Tool？
3. 为什么向量数据库返回 Top-K 不等于“真的检索到了答案”？
4. 为什么 Tavily 应该作为独立 Tool，而不是硬编码进 Retriever？
5. SQLite 和历史摘要分别解决什么问题？
6. `create_agent` 最终是怎样把 Model、Tools、Memory 组合起来的？

如果这 6 个问题能够自己讲清楚，这个项目才真正属于你。

---

# 1. 最终系统架构

```text
                              User
                                |
                                v
                     LangChain create_agent
                                |
                        init_chat_model
                                |
               Agent 自主判断是否调用工具
                                |
        +-----------------------+--------------------------+
        |                       |                          |
        v                       v                          v
 recommend_size          convert_weight          search_knowledge_base
        |                                               |
        v                                               v
 size_chart.json                                  Local Chroma RAG
                                                        |
                                              Relevance Gate
                                                        |
                                      +-----------------+----------------+
                                      |                                  |
                                   sufficient                         insufficient
                                      |                                  |
                                      v                                  v
                                     MMR                        Agent 可调用 web_search
                                      |                                  |
                              Neighbor Expansion                         v
                                      |                            Tavily Search API
                                      +----------------+-----------------+
                                                       |
                                                       v
                                                   Final Answer

Memory:
    SqliteSaver
        +
    SummarizationMiddleware
```

---

# 2. 为什么从传统 RAG 改成 Agent？

传统固定式 RAG 通常是：

```text
User
 -> Retriever
 -> Vector DB
 -> Prompt
 -> LLM
```

它的问题是任何问题都会先检索。

例如：

```text
你好
```

也去检索。

```text
160斤是多少公斤？
```

也去检索。

这说明程序并没有“选择能力”。

Agent 版本改成：

```text
User
 -> Agent
      |- 普通聊天 -> 直接回答
      |- 尺码 -> recommend_size
      |- 单位 -> convert_weight
      |- 本地服装知识 -> search_knowledge_base
      `- 最新/公网知识 -> web_search
```

因此 RAG 不再等于整个系统，而只是 Agent 的一个 Tool。

---

# 3. 第一个文件：`requirements.txt`

先建立虚拟环境：

```bash
python -m venv .venv
```

Windows：

```bash
.venv\Scripts\activate
```

macOS / Linux：

```bash
source .venv/bin/activate
```

然后安装：

```bash
pip install -r requirements.txt
```

本项目主要依赖：

```text
langchain
langgraph
langgraph-checkpoint-sqlite
langchain-openai
langchain-tavily
langchain-community
langchain-chroma
langchain-text-splitters
chromadb
dashscope
python-dotenv
pydantic
```

其中：

- `langchain`：Agent、Tool、Middleware；
- `langgraph`：Agent runtime/state；
- `langgraph-checkpoint-sqlite`：SQLite checkpoint；
- `langchain-openai`：让 `init_chat_model` 通过 OpenAI-compatible 协议访问 Qwen；
- `langchain-tavily`：Tavily 官方 LangChain 集成；
- `langchain-chroma`：Chroma；
- `langchain-text-splitters`：递归切分；
- `dashscope`：Embedding；
- `pydantic`：Tool 的结构化参数。

Tavily 当前官方 LangChain 集成使用：

```python
from langchain_tavily import TavilySearch
```

而不是旧的 `langchain_community.tools.tavily_search`。

---

# 4. 第二个文件：`.env`

复制：

```text
.env.example
```

变成：

```text
.env
```

## 4.1 Qwen

```text
MODEL_PROVIDER=openai
MODEL_NAME=qwen3-max
MODEL_API_KEY=你的DashScopeKey
MODEL_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

注意：

`MODEL_PROVIDER=openai` 并不是说 Qwen 是 OpenAI 模型。

这里表示：

```text
LangChain OpenAI provider adapter
        -> OpenAI-compatible protocol
        -> DashScope endpoint
        -> Qwen
```

## 4.2 Embedding

```text
DASHSCOPE_API_KEY=你的DashScopeKey
EMBEDDING_MODEL_NAME=text-embedding-v4
```

## 4.3 Tavily

```text
TAVILY_ENABLED=true
TAVILY_API_KEY=你的TavilyKey
TAVILY_MAX_RESULTS=5
TAVILY_TOPIC=general
TAVILY_SEARCH_DEPTH=advanced
```

为什么：

```text
TAVILY_INCLUDE_ANSWER=false
TAVILY_INCLUDE_RAW_CONTENT=false
```

因为本项目遵循：

```text
Tavily = Search
Main Agent = Reasoning + Final Answer
```

不需要让 Tavily 先生成一遍答案，再让主 Agent 生成第二遍。

---

# 5. 第三个文件：`config.py`

这一层只负责读取配置。

不要让业务代码里到处出现：

```python
k = 3
threshold = 0.45
chunk_size = 800
```

统一放到：

```python
settings.retrieval_top_k
settings.retrieval_relevance_threshold
settings.chunk_size
```

这样以后修改参数，只改 `.env`。

当前版本重点包含：

```python
retrieval_gate_k
retrieval_relevance_threshold
```

和：

```python
tavily_enabled
tavily_api_key
tavily_max_results
tavily_topic
tavily_search_depth
```

---

# 6. 第四个文件：`models/model_factory.py`

这是模型抽象层。

核心：

```python
from langchain.chat_models import init_chat_model
```

Agent 不写：

```python
ChatTongyi(...)
```

也不直接写：

```python
ChatOpenAI(...)
```

而统一：

```python
init_chat_model(
    model=model_name,
    model_provider=provider,
    ...
)
```

你应该理解三个工厂：

```text
create_chat_model
    -> 主 Agent

create_summary_model
    -> 历史摘要

create_embedding_model
    -> RAG Embedding
```

Chat Model 与 Embedding 并不是同一种模型。

---

# 7. 第五个文件：`rag/text_splitter.py`

这是整个 RAG 部分最值得学习的文件之一。

## 7.1 不采用固定 800 字硬切

错误理解：

```text
每800字符
 -> 切一刀
```

本项目实际是：

```text
标题结构
 -> LogicalSection
 -> 如果 <= 800：不切
 -> 如果 > 800：递归自然边界切分
```

## 7.2 标题结构

程序识别：

```text
一、春季服装
```

以及：

```text
1. 纯棉材质
```

从而把：

```text
标题
洗涤规则
养护规则
```

尽量放进同一个逻辑块。

## 7.3 超长时再 Recursive Split

顺序：

```text
\n\n
\n
。
！
？
；
，
...
```

只有前面的边界不能满足 chunk size 时，才继续向更细粒度退化。

## 7.4 overlap

超长 section 才使用 overlap：

```text
CHUNK_OVERLAP=120
```

减少边界上下文丢失。

---

# 8. 先不要建数据库：写 `scripts/preview_chunks.py`

此时马上运行：

```bash
python scripts/preview_chunks.py
```

你需要人工观察：

- 羊毛的洗涤和养护有没有被无意义拆开；
- 一级标题/二级标题有没有跟正文一起保存；
- 是否存在很小、没有意义的 chunk。

RAG 的第一步不是调模型，而是先看数据。

---

# 9. `rag/vector_store.py`

VectorStoreService 只做数据库操作。

该服务包含四个重要方法。

## 9.1 `add_documents`

写 Chroma。

## 9.2 `relevance_search`

```python
similarity_search_with_relevance_scores(...)
```

用于判断：

> 本地知识库是真的有相关答案，还是只是在所有错误答案里选了一个“最像的”？

## 9.3 `mmr_search`

MMR 同时考虑：

```text
query relevance
+
result diversity
```

减少三个结果都在重复同一件事。

## 9.4 `get_by_ids`

用于读取 anchor 前后的邻居 chunk。

---

# 10. `rag/knowledge_base.py`

完整入库链路：

```text
TXT
 -> normalize
 -> document_id
 -> StructureAwareTextSplitter
 -> chunk_id
 -> metadata
 -> embedding
 -> Chroma
```

## 10.1 为什么 chunk_id 是确定性的？

例如：

```text
abc123_0000
abc123_0001
abc123_0002
```

命中：

```text
abc123_0001
```

程序马上知道前后邻居：

```text
abc123_0000
abc123_0002
```

这就是 Neighbor Expansion 的基础。

## 10.2 为什么尺码 TXT 不主要进入 RAG？

因为：

```text
175-182cm
145-165斤
-> 2XL
```

这是确定性规则。

因此：

```text
TXT -> size_chart.json -> recommend_size
```

比：

```text
TXT -> embedding -> LLM 猜
```

稳定。

---

# 11. 初始化知识库

```bash
python scripts/init_knowledge_base.py
```

正式进入 RAG 的主要是：

```text
洗涤养护.txt
颜色选择.txt
```

尺码规则走 JSON Tool。

---

# 12. `rag/retriever.py` 的 Relevance Gate

这是 Tavily 兜底真正成立的前提。

## 12.1 为什么 `if not documents` 不够？

假设知识库只有服装知识。

用户问：

```text
MacBook Pro 怎么充电？
```

向量数据库仍可能返回：

```text
资料1：羊毛洗涤
资料2：服装配色
```

因为它的任务是：

> 在已有数据中找最相近的。

并不是：

> 判断有没有正确答案。

因此：

```python
if documents:
```

没有任何质量保证。

## 12.2 Gate

先：

```text
similarity_search_with_relevance_scores
```

获得：

```text
(doc1, 0.82)
(doc2, 0.61)
(doc3, 0.44)
```

取最高：

```text
best_score = 0.82
```

比较：

```text
best_score >= threshold
```

如果通过：

```text
LOCAL_KB_STATUS=SUFFICIENT
```

否则：

```text
LOCAL_KB_STATUS=INSUFFICIENT
```

## 12.3 0.45 是绝对真理吗？

不是。

这是非常重要的面试点。

Threshold 依赖：

- Embedding 模型；
- 数据规模；
- 文档质量；
- 查询分布。

所以本项目提供：

```bash
python scripts/inspect_relevance.py
```

进行人工校准。

---

# 13. `scripts/inspect_relevance.py`

里面准备两组问题。

本地应该命中：

```text
羊毛衣物怎么洗？
正式面试穿黑色合适吗？
```

明显无关：

```text
MacBook Pro 怎么充电？
东京天气怎么样？
```

运行后观察两组分数。

如果：

```text
相关问题：0.70 ~ 0.90
无关问题：0.20 ~ 0.40
```

可以把阈值放在：

```text
0.50 左右
```

真实项目还应该建立验证集，而不是只看三条问题。

---

# 14. `tools/knowledge_tool.py`

现在 RAG 被包装为 Agent Tool：

```text
search_knowledge_base
```

重点是 Tool 返回的不只是正文。

它还返回：

```text
LOCAL_KB_STATUS=SUFFICIENT
```

或：

```text
LOCAL_KB_STATUS=INSUFFICIENT
```

Agent 可以依据结果继续决策。

这就是：

```text
Tool Call
 -> Observation
 -> 下一步 Tool Decision
```

而不是程序提前把整个流程写死。

---

# 15. `tools/size_tool.py`

职责：

```text
height
weight
fit_preference
 -> size
```

这是确定性业务 Tool。

LLM 负责：

```text
提取参数 + 决定调用
```

Python 负责：

```text
真正计算
```

原则：

> LLM 做模糊理解，代码做确定性执行。

---

# 16. `tools/weight_tool.py`

很简单：

```text
jin <-> kg
```

但它展示了同一个设计原则。

不要让模型凭语言能力计算本来可以确定性完成的业务逻辑。

---

# 17. `tools/web_search_tool.py`

## 17.1 为什么 Tavily 是独立 Tool？

不写：

```text
search_knowledge_base()
    if fail:
        tavily()
```

而写：

```text
Tool 1: search_knowledge_base
Tool 2: web_search
```

好处：

1. 实时问题可以直接 web_search；
2. 本地问题不会无意义联网；
3. 工具职责单一；
4. Agent 的 Tool Trace 更清楚；
5. 后面替换搜索引擎更容易。

## 17.2 Tavily 初始化

```python
TavilySearch(
    max_results=5,
    topic="general",
    search_depth="advanced",
    include_answer=False,
    include_raw_content=False,
)
```

## 17.3 为什么 Tool 最后格式化结果？

Agent 更容易读：

```text
[联网资料1]
标题：...
URL：...
摘要：...
```

而不是处理一大段复杂原始 JSON。

---

# 18. 单独测试 Tavily

```bash
python tests/test_web_search.py
```

先证明：

```text
Python -> Tavily API
```

没有问题，再测试 Agent。

这样出现错误时更容易定位。

---

# 19. `agent/prompts.py`

这里有两个完全不同的 Prompt。

## 19.1 `SYSTEM_PROMPT`

教 Agent：

- 什么时候直接回答；
- 什么时候使用本地知识；
- 什么时候使用 Tavily；
- 什么时候使用尺码 Tool；
- 本地结果不足时怎么处理。

当前 Agent 最重要的路由规则：

```text
LOCAL_KB_STATUS=INSUFFICIENT
+
问题属于公开知识
 -> 可以 web_search
```

以及：

```text
最新 / 近期 / 今年 / 当前趋势
 -> 可以直接 web_search
```

## 19.2 `MEMORY_SUMMARY_PROMPT`

完全不是 Tool Routing。

它只负责告诉摘要模型：

> 哪些旧聊天值得长期保留？

例如：

- 身高；
- 体重；
- 穿衣偏好；
- 已经做过的选择；
- 未解决事项；
- 影响后续决策的重要联网结论。

---

# 20. `memory/sqlite_memory.py`

SQLite 只解决：

```text
程序关闭
 -> 历史仍然存在
```

核心：

```python
SqliteSaver(connection)
```

同一个：

```text
thread_id=user_001
```

下次运行仍能恢复 Agent state。

---

# 21. `memory/summary_middleware.py`

摘要解决的不是持久化。

它解决：

```text
历史太长
 -> Context Window 不断增长
```

默认：

```text
tokens >= 6000
OR
messages >= 30
```

触发。

然后：

```text
旧消息 -> summary
最近10条 -> 原文
```

所以：

```text
SQLite = Save
Summary Middleware = Compress
```

一定不要混淆。

---

# 22. 最后才写 `agent/agent_service.py`

到这一步，底层所有零件已经完成。

最终组装：

```python
create_agent(
    model=model,
    tools=tools,
    system_prompt=SYSTEM_PROMPT,
    middleware=[summary_middleware],
    checkpointer=sqlite_saver,
)
```

这一行背后就是：

```text
Model
+
Tools
+
Prompt
+
Memory
=
Agent
```

Agent Tools：

```text
search_knowledge_base
recommend_size
convert_weight
web_search
```

---

# 23. Agent 的典型执行路径

## 23.1 问候

用户：

```text
你好
```

执行：

```text
Agent
 -> Final Answer
```

没有 Tool。

## 23.2 尺码

```text
我178cm，160斤穿什么？
```

执行：

```text
Agent
 -> recommend_size
 -> Tool Result
 -> Final Answer
```

## 23.3 本地知识

```text
羊毛衫怎么洗？
```

执行：

```text
Agent
 -> search_knowledge_base
 -> Gate sufficient
 -> MMR
 -> Neighbor Expansion
 -> Tool Result
 -> Final Answer
```

## 23.4 本地不足再联网

```text
莫代尔怎么护理？
```

如果本地没有：

```text
Agent
 -> search_knowledge_base
 -> LOCAL_KB_STATUS=INSUFFICIENT
 -> web_search
 -> Tavily Result
 -> Final Answer
```

## 23.5 实时问题

```text
2026年秋冬最新流行色是什么？
```

可以：

```text
Agent
 -> web_search
 -> Final Answer
```

不必浪费一次本地 RAG。

---

# 24. 测试顺序

不要一上来运行 `main.py`。

正确顺序：

## 24.1 Chunk

```bash
python scripts/preview_chunks.py
python tests/test_text_splitter.py
```

## 24.2 确定性 Tool

```bash
python tests/test_tools.py
```

## 24.3 建库

```bash
python scripts/init_knowledge_base.py
```

## 24.4 Gate

```bash
python scripts/inspect_relevance.py
python tests/test_retrieval_gate.py
```

## 24.5 Tavily

```bash
python tests/test_web_search.py
```

## 24.6 Agent

```bash
python tests/test_agent.py
```

## 24.7 最终 CLI

```bash
python main.py
```

---

# 25. `tests/test_agent.py` 应该观察什么？

不是只看答案通顺不通顺。

重点看 Tool Trace。

### `你好`

应该：

```text
No Tool
```

### `160斤多少kg`

应该看到：

```text
convert_weight
```

### `178 / 160斤穿什么码`

应该：

```text
recommend_size
```

### `羊毛怎么洗`

应该：

```text
search_knowledge_base
```

### `2026最新流行色`

应该：

```text
web_search
```

### 本地没有的服装知识

理想：

```text
search_knowledge_base
 -> INSUFFICIENT
 -> web_search
```

---

# 26. 怎么验证 SQLite Memory？

第一次：

```bash
python main.py
```

Thread：

```text
user_001
```

说：

```text
我178cm，160斤，喜欢宽松版型。
```

退出。

重新运行同一个 thread：

```text
user_001
```

问：

```text
那我应该选多大？
```

如果 Agent 能利用之前的信息，持久化有效。

---

# 27. 怎么验证摘要 Memory？

为了快速观察，临时修改：

```text
SUMMARY_TRIGGER_MESSAGES=8
SUMMARY_TRIGGER_TOKENS=50000
SUMMARY_KEEP_MESSAGES=4
```

连续聊天。

然后：

```text
:history
```

观察旧消息是否被摘要压缩。

测试完再恢复正式参数。

---

# 28. 修改 Chunk 参数后为什么必须重建 Chroma？

例如：

```text
CHUNK_SIZE=800
```

改成：

```text
CHUNK_SIZE=500
```

文档虽然没变，但向量单元已经变了。

因此：

```bash
python scripts/reset_knowledge_base.py
python scripts/init_knowledge_base.py
```

---

# 29. Relevance Threshold 怎么进一步做成真正工程方案？

小规模项目可以从人工观察开始。

更正式的项目应该准备：

```text
50条 in-domain query
50条 out-of-domain query
```

记录：

```text
best relevance score
```

然后计算：

- Precision；
- Recall；
- F1；
- false positive；
- false negative。

找到合适 threshold。

这可以成为你后续继续升级项目的一个实验点。

---

# 30. 为什么 Tavily 不应该无条件调用？

因为联网有：

- 网络延迟；
- API 成本；
- 信息质量差异；
- 实时网页噪声；
- 内部知识与公网知识冲突风险。

所以本项目是：

```text
Local-first
+
Web fallback
```

而不是：

```text
Every Query -> Web Search
```

---

# 31. 如果本地知识和 Web 冲突怎么办？

例如公司的内部尺码表说：

```text
178/160 -> 2XL
```

网页说：

```text
某品牌 -> XL
```

本系统必须优先：

```text
recommend_size
```

因为这是当前系统的内部规则。

但是：

```text
2026 秋冬趋势
```

本地 2024 静态文档和 2026 Web 信息冲突时，应优先时效性更强的 Web 来源。

所以知识优先级不是固定“谁永远最高”，而与知识类型有关。

---

# 32. 复现时完整工程编写顺序

严格推荐：

```text
01 requirements.txt
02 .env
03 config.py
04 models/model_factory.py
05 rag/text_splitter.py
06 scripts/preview_chunks.py
07 rag/vector_store.py
08 rag/knowledge_base.py
09 scripts/init_knowledge_base.py
10 rag/retriever.py
11 scripts/inspect_relevance.py
12 tools/knowledge_tool.py
13 tools/size_tool.py
14 tools/weight_tool.py
15 tools/web_search_tool.py
16 agent/prompts.py
17 memory/sqlite_memory.py
18 memory/summary_middleware.py
19 agent/agent_service.py
20 tests/*
21 main.py
```

为什么最后才写 Agent？

因为 Agent 是上层“组装者”。

如果底层 Tool、Retriever、Memory 都没有单独跑通，
直接调 Agent 出错时非常难定位。

---

# 33. 面试时你应该能够画出的图

```text
                 Single Agent
                     |
         +-----------+------------+
         |           |            |
   Structured     Local RAG      Web
     Tools            |            |
         |       Relevance Gate   Tavily
         |            |
         |       MMR + Neighbor
         +-----------+------------+
                     |
                  Response

Memory:
SQLite + SummarizationMiddleware
```

---

# 34. 你应该能够回答的面试问题

1. 为什么 RAG 不是主流程，而是 Tool？
2. 为什么尺码从 TXT RAG 改成 JSON Tool？
3. 为什么不是固定长度 Chunk？
4. MMR 解决什么问题？
5. Neighbor Expansion 解决什么问题？
6. 为什么 Top-K 不为空仍然可能没有答案？
7. Relevance Gate 怎么调阈值？
8. 为什么 Tavily 是独立 Tool？
9. 为什么最新问题直接 Web Search？
10. SQLite 和摘要 Middleware 有什么区别？
11. 为什么模型统一用 `init_chat_model`？
12. Tool Calling 和普通函数调用有什么不同？

如果这些问题都能自己回答，这个项目就已经可以很自然地用于简历和面试。

---

# 35. 最后记住整个项目的设计原则

```text
LLM
负责：理解、决策、工具调度、信息整合

Python Tool
负责：确定性业务逻辑

Chroma
负责：本地非结构化知识检索

Relevance Gate
负责：判断本地知识是否值得信任

Tavily
负责：公开互联网与时效信息

SQLite
负责：状态持久化

SummarizationMiddleware
负责：长期会话上下文压缩
```

一句话总结：

> 让 LLM 做它擅长的模糊决策，让确定性代码处理规则，让本地 RAG 提供私有知识，让 Web Search 补足外部与实时知识，并用持久化与摘要机制维持长期对话状态。
